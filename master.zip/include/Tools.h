#ifndef TOOLS_H_INCLUDED
#define TOOLS_H_INCLUDED
#include <vector>
#include <cstring>
#include <string>

//source function http://cpp0x.pl/artykuly/?id=64
std::vector <std:: string > split( char * napis, const char * ograniczniki = "\n\t " ) ;
#endif // TOOLS_H_INCLUDED
