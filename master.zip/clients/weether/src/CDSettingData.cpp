#include "CDSettingData.h"
#include <cstring>

CDSettingData::CDSettingData()
{
    strcpy (nameApplication, "Weather - dragon");
}

CDSettingData::~CDSettingData()
{

}
