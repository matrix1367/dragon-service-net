#include "IJob.h"


int IJob::GetID()
{
    return m_ID;
}
