#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define DLG_MAIN                                100
#define IDD_QUEUE                               102
#define IDR_MENU1                               103
#define IDD_DIALOG_SETTING                      107
#define DLG_MAIN_LISTVIEW                       40000
#define IDD_QUEUE_LISTVIEW                      40000
#define ID_QUEUE                                40000
#define IDD_DIALOG_SETTING_PORT                 41005
#define IDD_DIALOG_SETTING_IP                   41006
#define ID_MENU_SETTING                         41007
#define ID_MENU_EXIT                            41008
