/****************************************************************************
 ****************************************************************************
 ***
 ***   This header was generated from a Wine headers to make
 ***   information necessary for userspace to call into the Windows
 ***   kernel available to Dr. Memory.  It contains only constants,
 ***   structures, and macros generated from the original header, and
 ***   thus, contains no copyrightable information.
 ***
 ****************************************************************************
 ****************************************************************************/

/* from Wine /dlls/kernel32/kernel32_private.h */

/* Kernel32 undocumented and private function definitions */

BOOL
WINAPI
VerifyConsoleIoHandle(
    __in HANDLE Handle
    );
